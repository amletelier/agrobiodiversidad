library("sp")
library("maptools")
library("raster")
library("ggplot2")
library("rgdal")
library("rgeos") 

#######   Riqueza Especies    ##############################################################

setwd("~/Google Drive/PracticaBiogeo") ## Asignar directorio de trabajo

lista_modelos<-list.files("./", recursive = T, pattern = ".asc")
spp<-gsub(".*\\/","",lista_modelos)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

#i=1

algebra_sp<-for (i in 1:length(spp)){
   mod_entrada<-raster(paste("./","", spp[i],sep=""))
   cat(paste(i," Entra ",spp[i],"\n", sep=""))
   mod_salida<-mod_salida+mod_entrada
} 

writeRaster(mod_salida, paste("./","Riqueza_Total_Especies",sep=""),format="GTiff", overwrite=TRUE)

pdf(paste("./","Riqueza_Total_Especies.pdf",sep=""))
plot(mod_salida)
dev.off()

##### Riqueza de especies en cada Familia  ##############################################################
##### Malpighinaceae

setwd("~/Google Drive/PracticaBiogeo") ## Asignar directorio de trabajo

lista_sp<-list.files("./", recursive = T, pattern = "Malp.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
}

pdf(paste("./","Riqueza_Malpighinaceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Malpighinaceae_Fam",sep=""),format="GTiff")



###### Rutaceae
lista_sp<-list.files("./", recursive = T, pattern = "Ruta.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Rutaceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Rutaceae_Fam",sep=""),format="GTiff")


  
###### Sapotaceae
lista_sp<-list.files("./", recursive = T, pattern = "Sapo.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Sapotaceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Spapotacea_Fam",sep=""),format="GTiff")

###### Myrtaceae
lista_sp<-list.files("./", recursive = T, pattern = "Myrt.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Myrtaceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Myrtaceae_Fam",sep=""),format="GTiff")

###### Anacardiaceae
lista_sp<-list.files("./", recursive = T, pattern = "Anac.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Anacardiaceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Anacardiaceae_Fam",sep=""),format="GTiff")


###### Lauraceae
lista_sp<-list.files("./", recursive = T, pattern = "Laur.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Lauraceae.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Lauraceae_Fam",sep=""),format="GTiff")


###### Leguminoceae
lista_sp<-list.files("./", recursive = T, pattern = "Legu.asc")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Leguminocea.pdf",sep=""))
plot(mod_salida)
dev.off()

table(mod_salida[])
mod_salida[mod_salida>=1]<-1
table(mod_salida[])
writeRaster(mod_salida, paste("./","Riqueza_Leguminoceae_Fam",sep=""),format="GTiff")


######  Riqueza  de Familias    #############################################################
lista_sp<-list.files("./", recursive = T, pattern = "Fam.tif")
spp<-gsub(".*\\/","",lista_sp)
spp<-unique(spp)
spp
mod_salida<-raster("./modelo_0.asc")

algebra_sp<-for (i in 1:length(spp)){
  mod_entrada<-raster(paste("./","", spp[i],sep=""))
  cat(paste(i," Entra ",spp[i],"\n", sep=""))
  mod_salida<-mod_salida+mod_entrada
} 

pdf(paste("./","Riqueza_Familias.pdf",sep=""))
plot(mod_salida)
dev.off()

writeRaster(mod_salida, paste("./","Riqueza_Familias",sep=""),format="GTiff")


  